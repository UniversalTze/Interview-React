import { Link, useLoaderData, redirect, useNavigate } from "react-router-dom";
import { createQuestion, getSpecificQuestion, updateQuestion } from "../apis/questionsapi";
import { getSpecificInterview } from "../apis/interviewapi"
import { BaseAddEditForm } from "../components/BaseAddEditForm";

/**
 * Loader function for QuestionAddEditForm.
 *
 * Fetches the specific question if `questionid` is provided (edit mode),
 * and always fetches the interview data for context.
 *
 * @async
 * @param {Object} params - URL params, including interviewid and optional questionid
 * @param {Object} request - React Router request object for abort signal
 * @returns {Promise<Object>} Object containing `questionarr` and `interview`
 * @throws {Response} 404 if question not found
 */
export async function loader({ params, request }) {
  let questionarr = null;
  if (params.questionid) {
    // update
    questionarr = await getSpecificQuestion(params.interviewid, params.questionid, { signal: request.signal });
    if (!questionarr) throw new Response("Not Found", { status: 404 });

  }
  const interview = await getSpecificInterview(params.interviewid, { signal: request.signal });
  return { questionarr, interview };
}

/**
 * Action function for QuestionAddEditForm.
 *
 * Handles both creation and updating of a question:
 * - If `questionid` is present, updates the question.
 * - Otherwise, creates a new question for the given interview.
 *
 * @async
 * @param {Object} params - URL params, including interviewid and optional questionid
 * @param {Object} request - React Router request object containing formData
 * @returns {Promise<Response>} Redirects to the list of questions for the interview
 */
export async function action({ request, params }) {
  const form = await request.formData(); // submitted form data
  const payload = {
    interview_id: params.interviewid,
    question: form.get("question"),
    difficulty: form.get("difficulty"),
    username: "s4703754"
  };

  if (params.questionid) {
    payload.id = params.questionid;
    await updateQuestion(params.questionid, payload, { signal: request.signal });
    return redirect(`/interviews/${params.interviewid}/questions`);
  } else {
    await createQuestion(payload, { signal: request.signal });
    return redirect(`/interviews/${params.interviewid}/questions`);
  }
}

/**
 * QuestionAddEditForm Component
 *
 * Displays a form to add a new question or edit an existing one.
 * Includes fields for:
 * - Question text (textarea)
 * - Difficulty (dropdown)
 * 
 * Uses BaseAddEditForm for consistent styling and submit/cancel handling.
 *
 * @component
 * @returns {JSX.Element} Form for adding/editing a question
 */
export default function QuestionAddEditForm() {
  const data = useLoaderData(); // { interview }
  const navigate = useNavigate();
  const isEdit = Boolean(data?.questionarr); // questionarr may be null if new (create)
  let questiondata = {};
  if (isEdit) { 
    questiondata = data?.questionarr[0];
  }
  const interviewdata = data?.interview[0];

  return (
    <div className="container mt-4">
      <div className="row justify-content-center mb-3">
      <div className="col-lg-8">  {/* To align them, neded to ensure that they are working in the same column spacing*/}
        <Link
          to={`/interviews/${interviewdata.id}/questions`}
          className="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center"
          style={{ width: "11rem", height: "3rem" }}
        >
          <i className="bi bi-arrow-left-square-fill me-2"></i>
          Back To Questions
        </Link>
      </div>
      </div>
      <div className="d-flex justify-content-center">
        <div className="col-lg-8">
          <BaseAddEditForm  //everything bewteen this and closing tag is children
            title={isEdit ? "Edit Question" : "Add New Question"}
            submitLabel={isEdit ? "Update" : "Add Question"}
            cancel={() => navigate(-1)}
          >
          <div className="mt-3 mb-1 text-start">
              For Interview:<br />
              <span className="fw-bold"> {interviewdata.title}</span>
          </div>
            <div className="mb-3">
              <label htmlFor="question" className="form-label">
                Question *
              </label>  {/* try text area instead of input*/}
              <textarea
                id="question"
                name="question"
                type="text"
                rows={3}
                required
                className="form-control"
                placeholder="Question to be asked"
                defaultValue={questiondata?.question ?? ""}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="difficulty" className="form-label">
                Difficulty *
              </label>
              <select
                id="difficulty"
                name="difficulty"
                required
                className="form-select"
                defaultValue={questiondata?.difficulty ?? "Easy"}
              >
                <option value="Easy">Easy</option>
                <option value="Intermediate">Intermediate</option>
                 <option value="Advanced">Advanced</option>
              </select>
            </div>
          </BaseAddEditForm>
        </div>
      </div>
    </div>
  );
}
